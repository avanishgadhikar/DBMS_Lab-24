#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(){
	FILE* fptr = fopen("boats01.csv", "r");
	FILE* fptr1 = fopen("task04b.sql", "w");
	fprintf(fptr1, "use week12;\n");

	for(int i = 0; i < 4; i++){
		int bid;
		char bname[51];
		char colour[51];
		fscanf(fptr, "%d,%51[^,],%51[^\n]\n", &bid, bname, colour);
		fprintf(fptr1, "INSERT into boats values (%d, '%s', '%s');\n", bid, bname, colour);
	}
	fclose(fptr);
	fclose(fptr1);
	return 0;
}
