#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(){
	FILE* fptr = fopen("sailors04.csv", "r");
	FILE* fptr1 = fopen("task10.sql", "w");
	fprintf(fptr1, "use week12;\n");
		char  sid[51];
		char sname[501];
		char rating[3];
		char age[5];
		fscanf(fptr, "%s\n", sname);
	for(int i = 0; i < 100; i++){
		fscanf(fptr, "%4[^,],%51[^,],%3[^,],%s\n", sid, sname, rating, age);
		fprintf(fptr1, "INSERT into sailors values (%s, '%s', %s, %s);\n", sid, sname, rating, age);
	}
	fclose(fptr);
	fclose(fptr1);
	return 0;
}
