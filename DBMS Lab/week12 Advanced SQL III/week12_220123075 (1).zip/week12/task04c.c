#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(){
	FILE* fptr = fopen("reserves01.csv", "r");
	FILE* fptr1 = fopen("task04c.sql", "w");
	fprintf(fptr1, "use week12;\n");

	for(int i = 0; i < 10; i++){
		int sid;
		char bid[4];
		char date[51];
		fscanf(fptr, "%d,%4[^,],%51[^\n]\n", &sid, bid, date);
		fprintf(fptr1, "INSERT into reserves values (%d, %s, '%s');\n", sid, bid, date);
	}
	fclose(fptr);
	fclose(fptr1);
	return 0;
}
