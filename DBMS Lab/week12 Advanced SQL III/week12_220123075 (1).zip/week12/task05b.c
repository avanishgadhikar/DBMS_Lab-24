#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(){
	FILE* fptr = fopen("insert-boats02.csv", "r");
	FILE* fptr1 = fopen("task05b.sql", "w");
	fprintf(fptr1, "use week12;\n");
	char bid[51];
	char bname[51];
	char colour[51];
	fscanf(fptr, "%51[^,],%51[^,],%s\n", bid, bname, colour);
	for(int i = 0; i < 50; i++){
		fscanf(fptr, "%51[^,],%51[^,],%s\n", bid, bname, colour);
		fprintf(fptr1, "INSERT into boats values (%s, '%s', '%s');\n", bid, bname, colour);
	}
	fclose(fptr);
	fclose(fptr1);
	return 0;
}
