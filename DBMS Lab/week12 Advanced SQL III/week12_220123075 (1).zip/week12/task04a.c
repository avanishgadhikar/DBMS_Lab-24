#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(){
	FILE* fptr = fopen("sailors01.csv", "r");
	FILE* fptr1 = fopen("task04a.sql", "w");
	fprintf(fptr1, "use week12;\n");

	for(int i = 0; i < 10; i++){
		int sid;
		char sname[51];
		char rating[3];
		char age[5];
		fscanf(fptr, "%d,%51[^,],%3[^,],%5[^\n]\n", &sid, sname, rating, age);
		fprintf(fptr1, "INSERT into sailors values (%d, '%s', %s, %s);\n", sid, sname, rating, age);
	}
	fclose(fptr);
	fclose(fptr1);
	return 0;
}
