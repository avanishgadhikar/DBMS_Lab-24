-- TASK 01: Creating a database week12. 
drop database if exists week12;
create database week12;
use week12;
-- x

-- TASK 02: Creating the necessary schemas.
drop table if exists sailors;
create table sailors(
	sid int primary key,
    sname char(50),
    rating int,
    age decimal(3, 1)
);

drop table if exists boats;
create table boats(
	bid int primary key, 
    bname char(50), 
    bcolor char(50)
);

drop table if exists reserves;
create table reserves(
	sid int,
    bid int, 
    day char(50),
    foreign key (sid) references sailors(sid) on delete cascade on update cascade,
    foreign key (bid) references boats(bid) on delete cascade on update cascade,
    primary key (sid, bid, day)    
);
-- x

-- TASK 03: Creating necessary log tables. 
drop table if exists sailors_log;
create table sailors_log(
	sid int, 
    event_ba char(50),
    ops char(50), 
    date_time datetime,
    check (event_ba in ('before', 'after')),
    check (ops in ('insert', 'update', 'delete'))
);

drop table if exists boats_log;
create table boats_log(
	bid int, 
    event_ba char(50), 
	ops char(50), 
    date_time datetime,
    check (event_ba in ('before', 'after')),
    check (ops in ('insert', 'update', 'delete'))
);

drop table if exists reserves_log;
create table reserves_log(
	sid int, 
    bid int, 
    day char(10), 
    event_ba char(50), 
	ops char(50), 
    date_time datetime,
    check (event_ba in ('before', 'after')),
    -- check (ops in ('insert', 'update', 'delete'))
);

drop table if exists sailors_log_log;
create table sailors_log_log(
	sid int, 
    event_ba char(50), 
	ops char(50), 
    date_time datetime,
    check (event_ba in ('before', 'after')),
    -- check (ops in ('insert', 'update', 'delete'))
);

drop table if exists sailors_log_log_log;
create table sailors_log_log_log(
	sid int, 
    event_ba char(50), 
	ops char(50), 
    date_time datetime,
    check (event_ba in ('before', 'after')),
    -- check (ops in ('insert', 'update', 'delete'))
);
-- x

-- TASK 04: Populating the tables.
-- Run file 'task04a.sql'
select * from sailors;

-- Run file 'task04b.sql'
select * from boats;

-- Run file 'task04c.sql'
select * from reserves;
-- x

-- TASK 05: 
-- a. Creating trigger sailor_t1.
drop trigger if exists sailors_t1;
delimiter //
create trigger sailors_t1
before insert on sailors
for each row
begin 	
	insert into sailors_log values (new.sid, 'before', 'insert', current_timestamp());
end;//
delimiter ;
    
-- b. Creating trigger boats_t1.
drop trigger if exists boats_t1;
delimiter //
create trigger boats_t1
before insert on boats
for each row
begin
	insert into boats_log values (new.bid, 'before', 'insert', current_timestamp());
end; // 
delimiter ;

-- c. Creating a trigger reserves_t1.
drop trigger if exists reserves_t1;
delimiter //
create trigger reserves_t1
before insert on reserves
for each row
begin
	insert into reserves_log values (new.sid, new.bid, new.day, 'before', 'insert', current_timestamp());
end; //
delimiter ;

-- d. Creating a trigger sailors_t2.
drop trigger if exists sailors_t2;
delimiter //
create trigger sailors_t2
after update on sailors
for each row
begin 
	insert into sailors_log values (new.sid, 'after', 'update', current_timestamp());
end; //
delimiter ;

-- e. Creating a trigger boats_t2.
drop trigger if exists boats_t2;
delimiter //
create trigger boats_t2
after update on boats
for each row
begin 
	insert into boats_log values (new.bid, 'after', 'update', current_timestamp());
end; //
delimiter ;

-- f. Creating a trigger reserves_t2
drop trigger if exists reserves_t2;
delimiter //
create trigger reserves_t2
after update on reserves
for each row
begin 
	insert into reserves_log values (new.sid, new.bid, new.day, 'after', 'update', current_timestamp());
end; //
delimiter ;

-- g. Creating a trigger sailors_t3.
drop trigger if exists sailors_t3;
delimiter //
create trigger sailors_t3
after delete on sailors
for each row
begin 
	insert into sailors_log values (old.sid, 'after', 'delete', current_timestamp());
end; //
delimiter ;

-- h. Creating a trigger boats_t3. 
drop trigger if exists boats_t3;
delimiter //
create trigger boats_t3
after delete on boats
for each row
begin
	insert into boats_log values (old.bid, 'after', 'delete', current_timestamp());
end; //
delimiter ;

-- i. Creating a table reserves_t3.
drop trigger if exists reserves_t3;
delimiter //
create trigger reserves_t3
after delete on reserves
for each row
begin
	insert into reserves_log values (old.sid, old.bid, old.day, 'after', 'delete', current_timestamp());
end; //
delimiter ;

-- x 

-- TASK 05: Populating Data and showing log files.
-- Run file 'task05a.sql'
select * from sailors;

-- Run file 'task05b.sql'
select * from boats;

-- Run file 'task05c.sql'
DELIMITER $$
CREATE PROCEDURE PopulateReserves()
BEGIN
    DECLARE sid_val INT;
    DECLARE bid_val INT;
    DECLARE day_val DATE;
    DECLARE count_val INT DEFAULT 0;

    RESERVE_LOOP: LOOP
        SELECT sid INTO sid_val FROM sailors ORDER BY RAND() LIMIT 1;
        SELECT bid INTO bid_val FROM boats ORDER BY RAND() LIMIT 1;
        SET day_val = DATE_ADD('2024-01-01', INTERVAL FLOOR(RAND() * 365) DAY);

        INSERT INTO reserves (sid, bid, day) VALUES (sid_val, bid_val, day_val);
        SET count_val = count_val + 1;

        IF count_val >= (SELECT COUNT(*) * 2 FROM sailors) THEN
            LEAVE RESERVE_LOOP;
        END IF;
    END LOOP;
END$$
DELIMITER ;
CALL PopulateReserves();
select * from reserves;

select * from sailors_log;
select * from boats_log;

-- Run file 'task05g.sql'
select * from sailors;
select * from sailors_log;

-- Run file 'task05h.sql'
select * from boats;
select * from boats_log;

select * from reserves_log;

-- Run file 'task05k.sql'
select * from sailors;
select * from sailors_log;

-- Run file 'task05l.sql'
select * from boats;
select * from boats_log;

select * from reserves_log;

-- x

-- TASK 06: Creating multiple triggers.
-- 1.
drop trigger if exists sailor_t2; 
delimiter //
create trigger sailor_t2
before insert on sailor
for each row 
	precedes sailors_t1
begin
	insert into sailors_log values (new.sid, 'before', 't2 insert', current_timestamp());
end;//
delimiter ;

-- 2.
drop trigger if exists sailor_t2; 
delimiter //
create trigger sailor_t2
before insert on sailor
for each row 
	precedes sailors_t1 -- AFTER t3
begin
	insert into sailors_log values (new.sid, 'before', 't3 insert', current_timestamp());
end;
follows insert on sailors_t1;
//
delimiter ;

-- x 

-- TASK 07: Populating table sailors.
-- Run file 'task07.sql'
select * from sailors_log;

-- x

-- TASK 08: Recursive Triggers.
drop trigger if exists sailor_log_t1;
delimiter //
create trigger sailor_log_t1
after insert on sailors_log
for each row
begin
	insert into sailors_log_log values (new.sid, new.event_ba, new.ops, current_timestamp());
end; //
delimiter ;

drop trigger if exists sailor_log_log_t1;
delimiter //
create trigger sailor_log_log_t1
after insert on sailors_log_log
for each row
begin
	insert into sailors_log_log_log values (new.sid, new.event_ba, new.ops, current_timestamp());
end; //
delimiter ;

-- x

-- TASK 10: Populating data.
-- Run file 'task10.sql'
select * from sailors_log;
select * from sailors_log_log;
select * from sailors_log_log_log;

-- TASK 11: 
drop trigger if exists sailor_log_log_log_t1;
delimiter //
create trigger sailor_log_log_log_t1
after insert on sailor_log_log_log
for each row
begin
	set @t1 = floor(rand()*100);
    set @t2 = floor(rand()*10 + 1);
    set @t3 = floor(rand() * 1000)/10;
    
	insert into sailors values (@t1, 'abc', @t2, @t3);
end; // 
delimiter ;

-- TASK 12: Populating Data.
-- Run file 'task12.sql'
select * from sailors_log;
select * from sailors_log_log;
select * from sailors_log_log_log;

-- x 

-- TASK 13: Populating Data and showing log files.
insert into sailors values (123, 'def', 9, 31);
insert into sailors values (123, 'def', 9, 31);
insert into sailors values (123, 'def', 9, 31);
insert into sailors values (123, 'def', 9, 31);
insert into sailors values (123, 'def', 9, 31);
insert into sailors values (123, 'def', 9, 31);
insert into sailors values (123, 'def', 9, 31);
insert into sailors values (123, 'def', 9, 31);
insert into sailors values (123, 'def', 9, 31);
insert into sailors values (123, 'def', 9, 31);
insert into sailors values (123, 'def', 9, 31);

insert into boats values (123, 'def', 'xyz');
insert into boats values (123, 'def', 'xyz');
insert into boats values (123, 'def', 'xyz');
insert into boats values (123, 'def', 'xyz');
insert into boats values (123, 'def', 'xyz');
insert into boats values (123, 'def', 'xyz');
insert into boats values (123, 'def', 'xyz');
insert into boats values (123, 'def', 'xyz');
insert into boats values (123, 'def', 'xyz');
insert into boats values (123, 'def', 'xyz');

insert into reserves values (123, 123, '12-06-2024');
insert into reserves values (123, 123, '12-06-2024');
insert into reserves values (123, 123, '12-06-2024');
insert into reserves values (123, 123, '12-06-2024');
insert into reserves values (123, 123, '12-06-2024');
insert into reserves values (123, 123, '12-06-2024');
insert into reserves values (123, 123, '12-06-2024');
insert into reserves values (123, 123, '12-06-2024');
insert into reserves values (123, 123, '12-06-2024');
insert into reserves values (123, 123, '12-06-2024');
insert into reserves values (123, 123, '12-06-2024');

select * from sailors_log;
select * from boats_log;
select * from reserves_log;


-- XXX --
