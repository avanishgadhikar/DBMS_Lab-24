#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(){
	FILE* fptr = fopen("update-boats02.csv", "r");
	FILE* fptr1 = fopen("task05h.sql", "w");
	fprintf(fptr1, "use week12;\n");
	char sid[51];
	char sname[51];	
	fscanf(fptr, "%51[^,],%s\n", sid, sname);
	for(int i = 0; i < 20; i++){
		fscanf(fptr, "%51[^,],%s\n", sid, sname);
		fprintf(fptr1, "UPDATE boats SET boats.bcolor = '%s' where boats.bid = %s;\n", sname, sid);
	}
	fclose(fptr);
	fclose(fptr1);
	return 0;
}
