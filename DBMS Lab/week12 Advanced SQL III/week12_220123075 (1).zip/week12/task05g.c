#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(){
	FILE* fptr = fopen("update-sailors02.csv", "r");
	FILE* fptr1 = fopen("task05g.sql", "w");
	fprintf(fptr1, "use week12;\n");
	char sid[51];
	char sname[51];	
	for(int i = 0; i < 100; i++){
		fscanf(fptr, "%51[^,],%s\n", sid, sname);
		fprintf(fptr1, "UPDATE sailors SET sailors.rating = %s where sailors.rating = %s;\n", sid, sname);
	}
	fclose(fptr);
	fclose(fptr1);
	return 0;
}
