#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(){
	FILE* fptr = fopen("delete-boats02.csv", "r");
	FILE* fptr1 = fopen("task05l.sql", "w");
	fprintf(fptr1, "use week12;\n");
	char sid[51];
	for(int i = 0; i < 10; i++){
		fscanf(fptr, "%s\n", sid);
		fprintf(fptr1, "DELETE FROM boats where boats.bid = %s;\n", sid);
	}
	fclose(fptr);
	fclose(fptr1);
	return 0;
}
