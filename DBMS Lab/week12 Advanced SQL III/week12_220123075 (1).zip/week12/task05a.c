#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(){
	FILE* fptr = fopen("insert-sailors02.csv", "r");
	FILE* fptr1 = fopen("task05a.sql", "w");
	fprintf(fptr1, "use week12;\n");
	char sid1[5];
	char sname1[51];
	char rating1[33];
	char age1[5];
	fscanf(fptr, "%5[^,],%51[^,],%33[^,],%s\n", sid1, sname1, rating1, age1);
	for(int i = 0; i < 500; i++){
		char sid[5];
		char sname[51];
		char rating[33];
		char age[5];
		fscanf(fptr, "%5[^,],%51[^,],%33[^,],%5[^\n]\n", sid, sname, rating, age);
		fprintf(fptr1, "INSERT into sailors values (%s, '%s', %s, %s);\n", sid, sname, rating, age);
	}
	fclose(fptr);
	fclose(fptr1);
	return 0;
}
