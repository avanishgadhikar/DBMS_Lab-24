#include<stdlib.h>
#include<stdio.h>
#include<string.h>
int main(){
	FILE* fptr;
	fptr = fopen("/home/h.gadhikar/Desktop/DBMS Lab/wk07/t01.csv", "r");
	FILE* fptr2;
	fptr2 = fopen("./task02.sql", "w");	
	int i = 500;
	char at; char bt; char ct; char dt; char et[20];
	fscanf(fptr, "%c,%c,%c,%c,%s\n", &at, &bt, &ct, &dt, et); 
	printf("insert into T01 values (%c, %c, %c, %c, '%s');\n", at, bt, ct, dt, et);
	fprintf(fptr2, "use week07;\n");
	while(i--){
		int a; int b; int c; int d; char e[20];	
		fscanf(fptr, "%d,%d,%d,%d,%s\n", &a, &b, &c, &d, e);
		fprintf(fptr2, "insert into T01 values (%d, %d, %d, %d, '%s');\n", a, b, c, d, e);
		
	}
	fclose(fptr);
	fclose(fptr2);

	return 0;
}
