-- TASK 01 - "Creating a database titled week07."
show databases;
create database week07;
show databases;
-- TASK END -- 

-- TASK 02 - "Creating Table T01 with columns a, b, c, d, e."
use week07;
create table T01(
	a int primary key,
    b int unique not null,
    c int unique not null,
    d int unique not null,
    e char(20) unique not null
);
show tables;
/*Now run the file titled 'task02.sql' to populate the table.*/
select * from T01;
/*Found 171 rows satisfying the primary key and unique and not null constraints of the table given 500 queries.*/
-- TASK END -- 

-- TASK 03 - "Creating a table T02 with columns c1, c2, c3."
use week07;
create table T02(
	c1 int primary key,
    c2 char(20) not null,
    c3 int not null
); 
show tables;
/*Table Created!*/
/*To populate the table run the file 'task03.sql'*/
select * from T02;
/*Found 464 rows satisfying the primary key and not null constraints out of 500 total queries.*/
-- TASK END --

-- TASK 04 - "Processing several queries."
-- 1. 
use week07;
select a, b, c, d, e from T01; 

-- 2.
use week07;
select a, b, c, d from T01;

-- 3. 
use week07;
select c, d, e from T01;

-- 4.
use week07;
select a, c, e from T01;

-- 5.
use week07;
select e, d, c, b, a from T01;

-- 6. 
use week07;
select a, (a + 10), b, (b - 20), c, (c * 30), d, (d / 40) from T01;

-- 7. 
use week07;
select * from T01;

-- 8. 
use week07;
select * from T01 order by e asc;

-- 9. 
use week07;
select * from T01 order by e desc;
-- TASK END --

-- TASK 05 - "Processing several different queries."
-- 1.
use week07;
select * from T01 where T01.a = 82941;
/*Found only 1 query as should be due to primary key constraint*/

-- 2.
use week07;
select a, b, c, d from T01 where T01.a <> 82941;
/*Found 170 rows satisfyng the constraint and listed the fisrt 4 columns.*/

-- 3.
use week07;
select c, d, e from T01 where T01.a > 84921;

-- 4.
use week07;
select a, c, e from T01 where T01.a >= 84921;

-- 5.
use week07;
select e, d, c, b, a from T01 where T01.a < 84921;

-- 6.
use week07;
select e, d, c, b, a from T01 where T01.a <= 84921;

-- 7.
use week07;
select e, d, c, b, a from T01 where T01.a between 80000 and 84921;

-- 8. 
use week07;
select a, (a + 10), b, (b - 20), c, (c * 30), d, (d / 40) from T01 where (T01.a between 80000 and 84921) and (T01.b <> 84921) and (T01.c > 40000) and (T01.d < 65000);

-- 9.
use week07;
select * from T01 where (T01.a between 0 and 50000) and (T01.b > 50000);

-- 10. 
use week07;
select * from T01 where (T01.a between 0 and 50000) and (T01.b > 50000) order by e asc;

-- 11.
use week07;
select * from T01 where (T01.a between 0 and 50000) and (T01.b > 50000) order by e asc, b desc;

-- TASK 06 - "Processing further different queries."
-- 1. 
use week07;
select e from T01 where T01.e like 'lo%';

-- 2. 
use week07;
select e from T01 where  T01.e like '%ing';

-- 3.
use week07;
select e from T01 where T01.e like '____';

-- 4. 
use week07;
select e from T01 where T01.e like '__i_'; 

-- 5. 
use week07;
select e from T01 where T01.e like '_i_h' or T01.e like '_i_l';

-- 6. 
use week07;
select e from T01 where (T01.e like '____') and not (T01.e like '__i_');

-- 7. 
use week07;
select e from T01 where not(T01.e like '_' or T01.e like '__' or T01.e like '___' or T01.e like '____' or T01.e like '_____' or T01.e like '______');
-- TASK END --

-- TASK 07 - "Processing queries using set operations."
-- 1. 
(select a, b from T01 where T01.a  > 50000)
union
(select c1, c3 from T02 where T02.c2 like 'e%');
/*Union performed as running only 1st query would give 83 rows nad union gives 134 rows.*/
/*(select a, b, c1, c3 from T01, T02 where T01.a  > 50000)
union
(select a, b, c1, c3 from T01, T02 where T02.c2 like 'e%');
*/
-- The above commented code snippet would give us tuples of 4 satisfying the mentioned conditions.*/

-- 2.
use week07;
select * from T02 where (c1, c2, c3) in (select a, e, c from T01);

-- 3.
use week07;
select * from T02 where (c1, c2, c3) not in (select a, e, c from T01);
-- TASK END --
-- :)
