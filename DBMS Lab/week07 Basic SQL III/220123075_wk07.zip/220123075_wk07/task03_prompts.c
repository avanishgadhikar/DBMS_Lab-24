#include<stdlib.h>
#include<stdio.h>
#include<string.h>
int main(){
	FILE* fptr;
	fptr = fopen("/home/h.gadhikar/Desktop/DBMS Lab/wk07/t02.csv", "r");
	FILE* fptr2;
	fptr2 = fopen("./task03.sql", "w");	
	int i = 500;	
	fprintf(fptr2, "use week07;\n");
	while(i--){
		int a; int b; int c; int d; char e[21];	
		fscanf(fptr, "%d,%21[^,],%d\n", &a, e, &b);
		fprintf(fptr2, "insert into T02 values (%d, '%s', %d);\n", a, e, b);
		
	}
	fclose(fptr);
	fclose(fptr2);

	return 0;
}
