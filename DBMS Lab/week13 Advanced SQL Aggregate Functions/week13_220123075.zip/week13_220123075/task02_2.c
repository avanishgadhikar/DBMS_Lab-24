#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(){
	FILE* fptr = fopen("employees.csv", "r");
	FILE* fptr1 = fopen("task02_2.sql", "w");
	fprintf(fptr1, "use week13;\n");

	for(int i = 0; i < 8; i++){
		int sid;
		char ename[51];
		char elang[51];
		char sal [11];
		char gen[2];
		fscanf(fptr, "%d,%51[^,],%51[^,],%11[^,],%s\n", &sid, ename, elang, sal, gen);
		fprintf(fptr1, "INSERT into employees values (%d, '%s', '%s', %s, '%s');\n", sid, ename, elang, sal, gen);
	}
	fclose(fptr);
	fclose(fptr1);
	return 0;
}
