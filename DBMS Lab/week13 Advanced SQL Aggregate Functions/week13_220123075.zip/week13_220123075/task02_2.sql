use week13;
INSERT into employees values (1, 'John', 'Engineering', 80000, 'M');
INSERT into employees values (2, 'Sarah', 'Marketing', 75000, 'F');
INSERT into employees values (3, 'Mike', 'Sales', 85000, 'M');
INSERT into employees values (4, 'Emily', 'Engineering', 82000, 'F');
INSERT into employees values (5, 'Alex', 'Marketing', 77000, 'M');
INSERT into employees values (6, 'Lisa', 'HR', 78000, 'F');
INSERT into employees values (7, 'David', 'Engineering', 83000, 'M');
INSERT into employees values (8, 'Jessica', 'Sales', 87000, 'F');
