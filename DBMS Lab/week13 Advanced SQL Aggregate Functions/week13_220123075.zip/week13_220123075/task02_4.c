#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(){
	FILE* fptr = fopen("employee-languages.csv", "r");
	FILE* fptr1 = fopen("task02_4.sql", "w");
	fprintf(fptr1, "use week13;\n");

	for(int i = 0; i < 48; i++){
		char ename[51];
		char elang[51];
		fscanf(fptr, "%51[^,],%s\n", ename, elang);
		fprintf(fptr1, "INSERT into languages values ('%s', '%s');\n", ename, elang);
	}
	fclose(fptr);
	fclose(fptr1);
	return 0;
}
