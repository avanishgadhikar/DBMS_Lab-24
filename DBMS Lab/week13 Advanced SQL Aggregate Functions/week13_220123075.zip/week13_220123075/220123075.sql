-- TASK 01. Create Database week13. 

create database week13;
use week13;

-- x.

-- TASK 02. Creating necessary tables. 

create table employees(
	eid int primary key, 
    ename char(50),
    dept char(50), 
    salary decimal (10, 0),
    gender char(1), 
    check (gender in ('M', 'F'))
);

create table languages(
	ename char(50), 
    speaks char(50), 
    primary key (ename, speaks)
);

-- Run files 'task02_2.sql' and 'task02_4.sql'
select * from employees;
select * from languages;

-- x.

-- TASK 03. Obtaining department with the fewwest employees.

-- 1.
select a.dept as department
from (select count(eid) as count_emp, dept
from employees
group by dept) as a, (select min(count_emp) as m from (select count(eid) as count_emp, dept
from employees
group by dept) as a1) as b
where a.count_emp = b.m;

-- 2.
with s as
(select count(eid) as count_emp, dept
from employees
group by dept)
select a.dept as department
from (select rank() over w as erank, dept from s window w as (order by count_emp asc)) as a
where a.erank = 1;

-- x.

-- TASK 04. Obtaining max language speaking employees.
-- 1.
with s as (
select ename as EMPLOYEE, count(speaks) as count_lan
from languages
group by ename
)
select s.EMPLOYEE, count_lan
from (select max(count_lan) as m from s) as a, s
where s.count_lan = a.m;

-- 2.
with s as (
select ename as EMPLOYEE, count(speaks) as count_lan
from languages
group by ename
)
select a.ename as EMPLOYEE, a.count_lan 
from (select EMPLOYEE as ename, count_lan, rank() over w as erank from s window w as (order by count_lan desc)) as a
where a.erank = 1;

-- x.

-- TASK 05. Obtaining which gender has highest avg sal. 

-- 1. 
with s as(
select avg(salary) as avg_sal, gender
from employees
group by gender
)
select s.gender, s.avg_sal 
from(select max(avg_sal) as m from s) as a, s 
where s.avg_sal = a.m;

-- 2.
with s as(
select avg(salary) as avg_sal, gender
from employees
group by gender
)
select a.gender, a.avg_sal
from (select rank() over w as erank, gender, avg_sal from s window w as (order by avg_sal desc)) as a
where a.erank = 1;

-- TASK 06. 

-- 1.
select b.ename, b.salary
from(select rank() over w as erank, a.ename, a.salary
	from (select ename, salary from employees where dept = 'Marketing') as a
	window w as (order by a.salary desc)) as b
where b.erank = 1 or b.erank = 2;

-- 2. 
select a.ename, a.gender
from (select rank() over w as erank, ename, gender
	from employees
	window w as (partition by gender order by salary desc)) as a
where a.erank = 1;

-- x.

-- TASK 07. Creating and populating students table. 

create table students(
	sid int primary key, 
    sname char(50), 
    marks int, 
    gender char(6), 
    department char(11), 
    check (gender in ('Male', 'Female')), 
    check (department in ('CSE', 'Mathematics'))
);

-- Run file 'task07.sql'.
select * from students;

-- x.

-- TASK 08. 

-- 1. Assigning ranks to each student based on marks.
select a.sid, a.marks, a.srank 
from (select rank() over w as srank, sid, marks
from students
window w as (order by marks desc)) as a;

-- 2. Assigning Department wise ranks to each student.
select a.sid, a.department, a.marks, a.srank 
from (select rank() over w as srank, sid, marks, department
from students
window w as (partition by department order by marks desc)) as a;

-- 3. Assigning gender wise ranks to each student.
select a.sid, a.gender, a.marks, a.srank 
from (select rank() over w as srank, sid, marks, gender
from students
window w as (partition by gender order by marks desc)) as a;

-- 4. Assigning Department-wise, Gender-wise ranks to each student.
select a.sid, a.department, a.gender, a.srank 
from (select rank() over w as srank, sid, marks, gender, department
from students
window w as (partition by gender, department order by marks desc)) as a;

-- 5. Assigning a dense rank to each student.
select a.sid as sid, a.department as department, a.gender as gender, a.srank as srank, a.sdrank as sdrank
from (select rank() over w as srank, dense_rank() over w as sdrank, sid, marks, department, gender
from students
window w as (order by marks desc)) as a;

-- 6. Obtaining name and marks of students having

select first_value(marks) over w as first_highest, nth_value(marks, 100) over w as hundredth_highest, nth_value(marks, 200) over w as twohundredth_highest, last_value(marks) over w as last_highest 
from (select sname, marks from students) as a
window w as (order by marks desc);
-- 		a. 1st highest marks.
with c as (select first_value(marks) over w as first_highest 
from (select sname, marks from students) as a
window w as (order by marks desc))
select sname, marks
from students, c
where marks = c.first_highest limit 1;

-- 		b. 100th highest marks.
with c as (select nth_value(marks, 100) over w as hundredth_highest
from (select sname, marks from students) as a
window w as (order by marks desc))
select sname, marks
from students, c
where marks = c.hundredth_highest limit 1;
  

-- 		c. 200th highest marks.
with c as (select nth_value(marks, 200) over w as twohundredth_highest
from (select sname, marks from students) as a
window w as (order by marks desc))
select sname, marks
from students, c
where marks = c.twohundredth_highest limit 1;

-- 		d. Last highest marks. 
with c as (select first_value(marks) over w as last_highest 
from (select sname, marks from students) as a
window w as (order by marks asc))
select sname, marks
from students, c
where marks = c.last_highest  limit 1;
    
    
-- 8. Obtaining prev and next values for department rank.
select sname, marks, lag(marks) over w as previous_marks, lead(marks) over w as next_marks
from students
window w as (partition by department order by marks asc); 

-- XXX -- 
