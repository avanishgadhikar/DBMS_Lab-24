#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(){
	FILE* fptr = fopen("students-marks.csv", "r");
	FILE* fptr1 = fopen("task07.sql", "w");
	fprintf(fptr1, "use week13;\n");
	int sid;
	char sname[51];
	char marks[51];
	char gen [11];
	char dept[21];
	fscanf(fptr, "%s\n", sname);
	for(int i = 0; i < 500; i++){		
		fscanf(fptr, "%d,%51[^,],%51[^,],%11[^,],%s\n", &sid, sname, marks, gen, dept);
		fprintf(fptr1, "INSERT into students values (%d, '%s', %s, '%s', '%s');\n", sid, sname, marks, gen, dept);
	}
	fclose(fptr);
	fclose(fptr1);
	return 0;
}
