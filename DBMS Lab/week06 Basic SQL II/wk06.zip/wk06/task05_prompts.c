#include<stdlib.h>
#include<stdio.h>
#include<string.h>
int main(){
	FILE* fptr;
	fptr = fopen("/home/h.gadhikar/Desktop/DBMS Lab/wk06/database/t04.csv", "r");
	FILE* fptr2;
	fptr2 = fopen("./task05.sql", "w");	
	int i = 500;
	
	fprintf(fptr2, "use week06;\n");
	while(i--){
		int a; int b; int c; int d; int e;	
		fscanf(fptr, "%d,%d,\n", &a, &b);
		fprintf(fptr2, "insert into T04 values (%d, %d);\n", a, b);
		
	}
	fclose(fptr);
	fclose(fptr2);
	return 0;
}
