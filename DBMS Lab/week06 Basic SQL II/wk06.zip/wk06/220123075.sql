-- TASK 01 - "Creating a Database titled week06."
create database week06;
-- ---xxx---

-- TASK 02 - "Creating table T01."
 use week06; 
 create table T01(
	a int,
    b int,
    c int not null,
    d int not null,  
    e int,
    primary key(a, b),
    unique(c),
    unique(d)
);
describe T01;
select * from T01;
-- 503 total values received.
-- ---xxx---

-- TASK 03- "Creating Table T02 with columns f, a, b."

create table T02(
	f int primary key,
    a int, 
    b int, 
    foreign key(a, b) references T01(a, b)
);
describe T02;
select * from T02;
-- 295 total values received

-- ---xxx---

-- TASK 04 - "Creating Table T03 with columns h, i, f."

create table T03(
	h int primary key, 
    i int, 
    f int,
    foreign key(f) references T02(f)
);
describe T03;
select * from T03;
-- 200 reecords received
-- ---xxx---

-- TASK 05 - "Creating table T04 columns k, h."

create table T04(
	k int primary key,
    h int,
    foreign key(h) references T03(h)
);
describe T04;
select * from T04;
-- 160 records received
-- ---xxx---
show tables;

-- TASK 06 - "Deleting tables T01, T02, T03, T04."
delete from T01; -- ERROR THROWN: Cannot delete that row which has been referenced as a foreign key constraint by anopther row of a different attribute.
delete from T02; -- SAME ERROR AS ABOVE.
delete from T03; -- SAME ERROR AS ABOVE.
delete from T04; -- Successfully Deleted!
delete from T03; -- Successfully Deleted!
delete from T02; -- Successfully Deleted!
delete from T01; -- Successfully Deleted!
drop table T01; -- ERROR THROWN: cannot delete that scheme which contains a referenced attribute by another schema.
drop table T02; -- SAME ERROR AS ABOVE.
drop table T03; -- SAME ERROR AS ABOVE.
drop table T04; -- Successfully Deleted!
drop table T03; -- Successfully Deleted!
drop table T02; -- Successfully Deleted!
drop table T01; -- Successfully Deleted!

show tables;
-- ---xxx---

-- TASK 08 - "Creating identical schemas and perofrming cascading on deletion."

create table T01a(
	a int,
    b int,
    c int not null,
    d int not null,  
    e int,
    primary key(a, b),
    unique(c),
    unique(d)
);

create table T02a(
	f int, 
    a int,
    b int, 
    primary key(f),
    foreign key (a, b) references T01a(a, b) on delete cascade
);
show tables;

delete from T01a where T01a.a = 297 and T01a.b = 77408; -- Successfully Run!
delete from T01a where T01a.a = 606 and T01a.b = 48191; -- Successfully Run!
delete from T01a where T01a.a = 1071 and T01a.b = 47061; -- Successfully Run!
delete from T01a where T01a.a = 1080 and T01a.b = 48533; -- Successfully Run!
delete from T01a where T01a.a = 2268 and T01a.b = 21577; -- Successfully Run!
delete from T01a where T01a.a = 3130 and T01a.b = 79583; -- Successfully Run!
delete from T01a where T01a.a = 3613 and T01a.b = 84692; -- Successfully Run!
delete from T01a where T01a.a = 3713 and T01a.b = 19837; -- Successfully Run!
delete from T01a where T01a.a = 3720 and T01a.b = 49661; -- Successfully Run!
delete from T01a where T01a.a = 4036 and T01a.b = 38648; -- Successfully Run!

select * from T02a; -- Related queries have been deleted from T02a as well, hence showing CASCADING DELETION.

-- ---xxx---

-- TASK 09 - "Demonstrating Cascading On Updation."

create table T01b(
	a int,
    b int,
    c int not null,
    d int not null,  
    e int,
    primary key(a, b),
    unique(c),
    unique(d)
);

create table T02b(
	f int primary key,
    a int, 
    b int,
    foreign key(a, b) references T01b(a, b) on update cascade
);

update T01b set a = 298 where a = 297; -- Successfully Updated!
update T01b set a = 607 where a = 607; -- Successfully Updated!
update T01b set a = 21577 where a = 2269; --  No ROWS CHANGED
update T01b set a = 79583 where a = 3131; --  No ROWS CHANGED
update T01b set a = 49661 where a = 3721; -- No ROWS CHANGED
update T01b set a = 38648 where a = 4037; -- No ROWS CHANGED
update T01b set b = 47062 where b = 1071; -- Successfully Updated!
update T01b set b = 48534 where b = 1080; -- Successfully Updated!
update T01b set b = 84693 where b = 3613; -- Successfully Updated!
update T01b set b = 19838 where b = 3713; -- Successfully Updated!

select * from T02b;

-- ---xxx---

-- TASK 09- "Cascade On Deletion Updation."
create table T01c(
	a int,
    b int,
    c int not null,
    d int not null,  
    e int,
    primary key(a, b),
    unique(c),
    unique(d)
);

create table T02c(
	f int primary key,
    a int, 
    b int,
    foreign key(a, b) references T01b(a, b) on update cascade on delete cascade
);
delete from T01c where T01c.a = 297 and T01c.b = 77408; -- Successfully Run!
delete from T01c where T01c.a = 606 and T01c.b = 48191; -- Successfully Run!
delete from T01c where T01c.a = 1071 and T01c.b = 47061; -- Successfully Run!
delete from T01c where T01c.a = 1080 and T01c.b = 48533; -- Successfully Run!
delete from T01c where T01c.a = 2268 and T01c.b = 21577; -- Successfully Run!
delete from T01c where T01c.a = 3130 and T01c.b = 79583; -- Successfully Run!
delete from T01c where T01c.a = 3613 and T01c.b = 84692; -- Successfully Run!
delete from T01c where T01c.a = 3713 and T01c.b = 19837; -- Successfully Run!
delete from T01c where T01c.a = 3720 and T01c.b = 49661; -- Successfully Run!
delete from T01c where T01c.a = 4036 and T01c.b = 38648; -- Successfully Run!



-- ---xxx---

-- TASK 10 -
delete from T01a;
delete from T01b;
delete from T01c;
delete from T02a;
delete from T02b;
delete from T02c;
drop table T01a;
drop table T01b;
drop table T01c;
drop table T02a;
drop table T02b;
drop table T02c;

-- ----xxx---