#include<stdlib.h>
#include<stdio.h>
#include<string.h>
int main(){
	FILE* fptr;
	fptr = fopen("/home/h.gadhikar/Desktop/DBMS Lab/wk06/database/t01.csv", "r");
	FILE* fptr2;
	fptr2 = fopen("./task07a.sql", "w");	
	int i = 1000;
	
	fprintf(fptr2, "use week06;\n");
	while(i--){
		int a; int b; int c; int d; int e;	
		fscanf(fptr, "%d,%d,%d,%d,%d\n", &a, &b, &c, &d, &e);
		fprintf(fptr2, "insert into T01a values (%d, %d, %d, %d, %d);\n", a, b, c, d, e);
		
	}
	fclose(fptr);
	fclose(fptr2);
	
	fptr = fopen("/home/h.gadhikar/Desktop/DBMS Lab/wk06/database/t02-10.csv", "r");
	fptr2 = fopen("./task07b.sql", "w");	
	i = 10;
	
	fprintf(fptr2, "use week06;\n");
	while(i--){
		int a; int b; int c; int d; int e;	
		fscanf(fptr, "%d,%d,%d\n", &a, &b, &c);
		fprintf(fptr2, "insert into T02a values (%d, %d, %d);\n", a, b, c);
		
	}
	fclose(fptr);
	fclose(fptr2);
	
	return 0;
}
