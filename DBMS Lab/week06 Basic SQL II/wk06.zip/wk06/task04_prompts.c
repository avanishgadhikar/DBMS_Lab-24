#include<stdlib.h>
#include<stdio.h>
#include<string.h>
int main(){
	FILE* fptr;
	fptr = fopen("/home/h.gadhikar/Desktop/DBMS Lab/wk06/database/t03.csv", "r");
	FILE* fptr2;
	fptr2 = fopen("./task04.sql", "w");	
	int i = 500;
	
	fprintf(fptr2, "use week06;\n");
	while(i--){
		int a; int b; int c; int d; int e;	
		fscanf(fptr, "%d,%d,%d\n", &a, &b, &c);
		fprintf(fptr2, "insert into T03 values (%d, %d, %d);\n", a, b, c);
		
	}
	fclose(fptr);
	fclose(fptr2);
	return 0;
}
