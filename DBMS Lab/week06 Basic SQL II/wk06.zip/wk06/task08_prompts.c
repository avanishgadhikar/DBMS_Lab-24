#include<stdlib.h>
#include<stdio.h>
#include<string.h>
int main(){
	FILE* fptr;
	fptr = fopen("/home/h.gadhikar/Desktop/DBMS Lab/wk06/database/t01.csv", "r");
	FILE* fptr2;
	fptr2 = fopen("./task08a.sql", "w");	
	int i = 1000;
	
	fprintf(fptr2, "use week06;\n");
	while(i--){
		int a; int b; int c; int d; int e;	
		fscanf(fptr, "%d,%d,%d,%d,%d\n", &a, &b, &c, &d, &e);
		fprintf(fptr2, "insert into T01b values (%d, %d, %d, %d, %d);\n", a, b, c, d, e);
		
	}
	fclose(fptr);
	fclose(fptr2);
	
	fptr = fopen("/home/h.gadhikar/Desktop/DBMS Lab/wk06/database/t02-20.csv", "r");
	fptr2 = fopen("./task08b.sql", "w");	
	i = 20;
	
	fprintf(fptr2, "use week06;\n");
	while(i--){
		int a; int b; int c; int d; int e;	
		fscanf(fptr, "%d,%d,%d\n", &a, &b, &c);
		fprintf(fptr2, "insert into T02b values (%d, %d, %d);\n", a, b, c);
		
	}
	fclose(fptr);
	fclose(fptr2);
	
	return 0;
}
