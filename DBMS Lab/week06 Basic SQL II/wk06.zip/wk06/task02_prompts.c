#include<stdlib.h>
#include<stdio.h>
#include<string.h>
int main(){
	FILE* fptr;
	fptr = fopen("/home/h.gadhikar/Desktop/DBMS Lab/wk06/database/t01.csv", "r");
	FILE* fptr2;
	fptr2 = fopen("./task02.sql", "w");	
	int i = 1000;
	
	fprintf(fptr2, "use week06;\n");
	while(i--){
		int a; int b; int c; int d; int e;	
		fscanf(fptr, "%d,%d,%d,%d,%d\n", &a, &b, &c, &d, &e);
		fprintf(fptr2, "insert into T01 values (%d, %d, %d, %d, %d);\n", a, b, c, d, e);
		
	}
	fclose(fptr);
	fclose(fptr2);
	return 0;
}
